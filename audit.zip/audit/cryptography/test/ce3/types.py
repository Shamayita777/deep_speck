"""
Cryptographic Evidence CE3 Datatypes
====================================

Framework-level data structures for the Representation Interpretation
audit (CE3).

These dataclasses describe the information exchanged between the
Cryptographic Evidence framework and adapter implementations during
representation analysis.

The module is intentionally independent of any particular
cryptographic primitive, machine-learning architecture, probing
algorithm, or research paper.

Responsibilities
----------------
• Describe representation datasets
• Describe cryptographic target specifications
• Describe probe evaluation results

No experimental logic is implemented here.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

import numpy as np


# ============================================================
# Target Types
# ============================================================


class TargetType(Enum):
    """
    Type of cryptographic prediction task.

    The target type allows the framework to select an appropriate
    generic probing procedure without requiring any knowledge of the
    underlying cryptographic quantity.

    BINARY
        Two-class prediction.

    MULTICLASS
        Finite set of discrete classes.

    CONTINUOUS
        Continuous-valued cryptographic quantity.
    """

    BINARY = "binary"

    MULTICLASS = "multiclass"

    CONTINUOUS = "continuous"


# ============================================================
# Target Specification
# ============================================================


@dataclass(frozen=True, slots=True)
class TargetSpecification:
    """
    Cryptographic quantity to be decoded from a learned
    representation.

    The framework deliberately does not prescribe what this quantity
    should be. Instead, each adapter declares the quantity together
    with sufficient metadata for scientific interpretation.

    Framework-level admissibility constraints (validated elsewhere)
    include:

    • non-degenerate target
    • model-independent target
    • independently interpretable cryptographic meaning
    """

    name: str
    """
    Human-readable target name.

    Examples
    --------
    Differential Class
    Trail Probability
    Round Count
    """

    description: str
    """
    Brief explanation of the target.
    """

    target_type: TargetType
    """
    Binary, multiclass, or continuous.
    """

    labels: np.ndarray
    """
    Ground-truth target values.

    These labels must be generated independently of the model under
    evaluation.
    """

    theoretical_interpretation: str
    """
    Scientific meaning of the target.

    This field explains why the target corresponds to a meaningful
    cryptographic quantity.
    """


# ============================================================
# Representation Dataset
# ============================================================


@dataclass(frozen=True, slots=True)
class RepresentationDataset:
    """
    Dataset used for representation probing.

    The framework views a representation dataset simply as a matrix of
    learned representations paired with a declared cryptographic
    target.

    It makes no assumptions regarding

    • network architecture
    • hidden layer
    • feature dimensionality
    • probing algorithm
    """

    representations: np.ndarray
    """
    Matrix of learned representations.

    Shape
    -----
    (num_samples, representation_dimension)
    """

    target: TargetSpecification
    """
    Target declared by the adapter.
    """

    @property
    def num_samples(self) -> int:
        """
        Number of samples.
        """

        return int(self.representations.shape[0])

    @property
    def representation_dimension(self) -> int:
        """
        Representation dimensionality.
        """

        return int(self.representations.shape[1])

# ============================================================
# Probe Evaluation
# ============================================================

@dataclass(frozen=True, slots=True)
class ProbeEvaluation:
    """
    Intermediate result produced by representation probing.

    ProbeEvaluation is not the final CE3 audit result.

    Instead, it records the probing statistics produced during
    cross-validated probing. These statistics are later converted
    into the generic CryptographicTestResult used by the
    Cryptographic Evidence framework.
    """

    real_score_mean: float
    """
    Mean probe performance on the trained model
    representations across all folds.
    """

    control_score_mean: float
    """
    Mean probe performance on the control model
    representations across all folds.
    """

    selectivity_mean: float
    """
    Mean selectivity across all folds.

    Selectivity is defined as

        real_score - control_score

    computed independently for each fold and then averaged.
    """

    selectivity_values: list[float]
    """
    Per-fold selectivity values.

    These values are retained so that downstream statistical
    procedures (e.g., paired t-test or Wilcoxon signed-rank
    test) may be performed without repeating the probing
    experiment.
    """

    n_splits: int
    """
    Number of cross-validation folds.
    """
    metric_name: str
    """
    Performance metric used during probing.

    Examples
    --------
    Accuracy
    R²
    """

    target: TargetSpecification
    """
    Cryptographic target evaluated by the probe.
    """

# ============================================================
# Statistical Significance
# ============================================================

@dataclass(frozen=True, slots=True)
class PairedComparisonStatistic:
    """
    Statistical significance of a CE3 selectivity result.

    This dataclass represents the statistical interpretation of a
    ProbeEvaluation. It is produced after probing has completed and
    therefore remains a distinct stage from evidence generation,
    following Framework Principle 5 (Evidence and Interpretation).
    """

    test_name: str
    """
    Name of the statistical test.

    Example
    -------
    wilcoxon_signed_rank
    """

    alternative: str
    """
    Alternative hypothesis used by the statistical test.
    """

    statistic: float
    """
    Test statistic.
    """

    p_value: float
    """
    Statistical significance.
    """

    effect_size: float
    """
    Standardized effect size.
    """

    ci_low: float
    """
    Lower confidence interval bound.
    """

    ci_high: float
    """
    Upper confidence interval bound.
    """

    n_pairs: int
    """
    Number of paired observations used by the statistical test.
    """